﻿using System;
using RetailAppEFCore.Models;

namespace RetailAppEFCore
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new AppDbContext())
            {
                // Step 1: Check if category already exists
                var existingCategory = context.Categories.FirstOrDefault(c => c.Name == "Electronics");

                if (existingCategory == null)
                {
                    existingCategory = new Category { Name = "Electronics" };
                    context.Categories.Add(existingCategory);
                    context.SaveChanges();
                    Console.WriteLine("✅ Category inserted.");
                }
                else
                {
                    Console.WriteLine("⚠️ Category already exists.");
                }

                // Step 2: Add product with that category ID
                var product = new Product
                {
                    Name = "USB Cable",
                    Price = 249.99m,
                    CategoryId = existingCategory.Id
                };

                context.Products.Add(product);
                context.SaveChanges();
                Console.WriteLine("✅ Product inserted.");
            }
        }
    }
}
